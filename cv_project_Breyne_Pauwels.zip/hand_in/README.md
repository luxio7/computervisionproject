computer vision project
made by Rik Pauwels and Emile Breyne (r0629298)

CODE:
all auto-encoder and classification code is grouped in Encode_classify.py
Main files for the segmentation part are segmentation_train.py to train the model and segmentation_evaluate to show the results
